import { Component } from '@angular/core';

@Component({
  selector: 'items',
  templateUrl: '../item/item.component.html',
  styleUrls: ['../item/item.component.css']
})
export class AppComponent {
  title = 'app works!';
}
